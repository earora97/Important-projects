# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################

#@auth.requires_login()

def contact():
    return dict(message=T('Welcome to QuizWiz!'))


def index():
    """
    example action using the internationalization operator T and flash
    rendered by views/default/index.html or views/generic.html

    if you need a simple wiki simply replace the two lines below with:
    return auth.wiki()
    """
    return dict(message=T('Welcome to QuizWiz!'))

@auth.requires_login()
def processquestion():
        exist= db(db.leaderboard.user_id==auth.user.id).count()
        if exist==0:
                    db.leaderboard.insert(user_id=auth.user.id,username=auth.user.first_name,tally=0)
        Quizid=request.vars.quizid[:-1]
        Questionid=request.vars.questionid[:-1]
        Qarg=request.args(0,cast=int)
        ans=request.vars.group1
        var=request.vars.correctans[:-1]
        A="None"
        if var=="1":
            A=request.vars.op1
        if var=="2":
            A=request.vars.op2
        if var=="3":
            A=request.vars.op3
        if var=="4":
            A=request.vars.op4
        #stri=var[:-1]
        #post = request.vars.id
        like= db((db.myscore.userid==auth.user.id) & (db.myscore.quiz_id==Quizid)& (db.myscore.question_id==Questionid)).count()
        if like==0:
            if var==ans:
                db.myscore.insert(quiz_id=Quizid,question_id=Questionid,userid=auth.user.id,ans=ans,correct=1)
                U= db(db.leaderboard.user_id==auth.user.id).select()
                us=U[0]
                t=us.tally+10
                us.update_record(tally=t)
            else:
                db.myscore.insert(quiz_id=Quizid,question_id=Questionid,userid=auth.user.id,ans=ans,correct=0)
        #redirect(URL('show',args=[Quizid,Qarg]))
        return locals()
    
@auth.requires_login()
def mprocessquestion():
        exist= db(db.leaderboard.user_id==auth.user.id).count()
        if exist==0:
                    db.leaderboard.insert(user_id=auth.user.id,username=auth.user.first_name,tally=0)
        Quizid=request.vars.quizid[:-1]
        Questionid=request.vars.questionid[:-1]
        Qarg=request.args(0,cast=int)
        ans1=request.vars.group1
        ans2=request.vars.group2
        ans3=request.vars.group3
        ans4=request.vars.group4
        us=auth.user.id
        var=2
        ans=0
        var1=request.vars.tru1[:-1]
        var2=request.vars.tru2[:-1]
        var3=request.vars.tru3[:-1]
        var4=request.vars.tru4[:-1]
        #stri=var[:-1]
        #post = request.vars.id
        boo1=0
        if(((ans1=="1") and (var1=="True")) or ((ans1==None) and (var1=="False"))):
            boo1=1
        boo2=0
        if(((ans2=="2") and (var2=="True")) or ((ans2==None) and (var2=="False"))):
            boo2=1
        boo3=0
        if(((ans3=="3") and (var3=="True")) or ((ans3==None) and (var3=="False"))):
            boo3=1
        boo4=0
        if(((ans4=="4") and (var4=="True")) or ((ans4==None) and (var4=="False"))):
            boo4=1
        like= db((db.mscore.userid==auth.user.id) & (db.mscore.quiz_id==Quizid)& (db.mscore.ques_id==Questionid)).count()
        p=0
        if like==0:
            if ((boo1==1) and (boo2==1) and (boo3==1) and (boo4==1)):
                db.mscore.insert(quiz_id=Quizid,ques_id=Questionid,userid=auth.user.id,correct=1)
                U= db(db.leaderboard.user_id==auth.user.id).select()
                us=U[0]
                t=us.tally+20
                us.update_record(tally=t)
                #db.myscore.insert(quiz_id=Quizid, question_id=Questionid, userid=auth.user.id, correct=1)
                p=2
            else:
                db.mscore.insert(quiz_id=Quizid,ques_id=Questionid,userid=auth.user.id,correct=0)
                p=1
        
        #redirect(URL('show',args=[Quizid,Qarg]))
        return locals()



def edit():
    quiz = db.quiz(request.args(0)) or redirect(URL('error'))
    form=SQLFORM(db.quiz,quiz, deletable=True)
    if form.validate():
        if form.deleted:
            db(db.recipe.id==recipe.id).delete()
            redirect(URL('index'))
        else:
            recipe.update_record(**dict(form.vars))
            response.flash='Changes Accepted'
    return dict(form=form)

def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())

@auth.requires_membership('user_7')
def manage():
    grid1 = SQLFORM.smartgrid(db.quiz,linked_tables=['quiz'])
    return dict(grid1=grid1)
@auth.requires_membership('user_7')
def manage2():
    grid = SQLFORM.smartgrid(db.question,linked_tables=['question'])
    return dict(grid=grid)
@auth.requires_login()
def qinfo():
    qpost=db.quiz(request.args(0))
    db.post.quiz_id.default = qpost.id
    form = SQLFORM(db.post)
    if form.process().accepted:
        response.flash = 'your comment is posted'
    comments = db(db.post.quiz_id==qpost.id).select()
    return locals()

@auth.requires_login()
def mqinfo():
    qpost=db.mquiz(request.args(0))
    db.mpost.quiz_id.default = qpost.id
    form = SQLFORM(db.mpost)
    if form.process().accepted:
        response.flash = 'your comment is posted'
    comments = db(db.mpost.quiz_id==qpost.id).select()
    return locals()


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)

@auth.requires_login()
def list():
    files=db(db.quiz).select(orderby=~db.quiz.date_of_upload)
    return dict(files=files)
def example():
    files=db(db.quiz).select(orderby=~db.quiz.date_of_upload)
    return dict(files=files)

def list2():
    files=db(db.quiz).select(orderby=~db.quiz.date_of_upload)
    return dict(files=files)

@auth.requires_login()
def mlist():
    files=db(db.mquiz).select(orderby=~db.mquiz.date_of_upload)
    return dict(files=files)

@auth.requires_login()
def show():
    quiz=db(db.question.quiz_id==request.args(0)).select()
    l=len(quiz)
    var=request.args(1,cast=int)
    if var>=l:
        redirect(URL('score', args=request.args(0)))
    else:
        ques=quiz[var]
    return locals()

@auth.requires_login()
def mulshow():
    quiz=db(db.multiquestion.mquiz_id==request.args(0)).select()
    l=len(quiz)
    var=request.args(1,cast=int)
    if var>=l:
        redirect(URL('mscore', args=request.args(0)))
    else:
        ques=quiz[var]
    return locals()
@auth.requires_login()
def leaderboard():
    files=db(db.leaderboard).select(orderby=~db.leaderboard.tally)
    return locals()

@auth.requires_login()
def score():
    count = db((db.myscore.quiz_id==request.args(0))&(db.myscore.userid==auth.user.id)&(db.myscore.correct==1)).count()
    return locals()

@auth.requires_login()
def mscore():
    count = db((db.mscore.quiz_id==request.args(0))&(db.mscore.userid==auth.user.id)&(db.mscore.correct==1)).count()
    return locals()

@auth.requires_login()
def resume():
    count=db((db.myscore.quiz_id==request.args(0))&(db.myscore.userid==auth.user.id)).count()
    redirect(URL('show',args=[request.args(0),count]))
    return locals()

@auth.requires_login()
def mresume():
    count=db((db.mscore.quiz_id==request.args(0))&(db.mscore.userid==auth.user.id)).count()
    redirect(URL('mulshow',args=[request.args(0),count]))
    return locals()

def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()


@auth.requires_login()
def Searchquiz():
    form1 = FORM(INPUT(_type="text",_name="var"),_action="title_search")
    form2 = FORM(INPUT(_type="text",_name="var"),_action="genre_search")
    form3=FORM(INPUT(_id='keyword3',_name='keyword3', _onkeyup="ajax('callbackcomb', ['keyword3'], 'target3');"))
    target_div3=DIV(_id='target3')
    form4=FORM(INPUT(_id='keyword4',_name='keyword4', _onkeyup="ajax('callbackcomb2', ['keyword4'], 'target4');"))
    target_div4=DIV(_id='target4')
    return locals()

@auth.requires_login()
def title_search():
    var = str(request.vars["var"])
    files = db(db.quiz.TITLE==var).select()
    files2 = db(db.mquiz.TITLE==var).select()
    return locals()

@auth.requires_login()
def ajaxlivesearch():
    partialstr = request.vars.partialstr
    query = db.quiz.TITLE.like('%'+partialstr+'%')
    quizes = db(query).select(db.quiz.TITLE)
    items = []
    for (i,quiz) in enumerate(quizes):
        items.append(DIV(A(quiz.TITLE, _id="res%s"%i, _href="#", _onclick="copyToBox($('#res%s').html())"%i), _id="resultLiveSearch"))

    return TAG[''](*items)


def callbackcomb():
    if not request.vars.keyword3: return ''
    query1 = db.quiz.TITLE.contains(request.vars.keyword3)
    images = db(query1).select(orderby=db.quiz.TITLE)
    links1 = [A(p.TITLE + " (Single Correct)", _href=URL('qinfo',args=[p.id])) for p in images]
    query = db.mquiz.TITLE.contains(request.vars.keyword3)
    users = db(query).select(orderby=db.mquiz.TITLE)
    links = [A(p.TITLE +" (Multiple Correct)", _href=URL('mqinfo',args=[p.id])) for p in users]
    links = links+links1
    return DIV(*[DIV(k,  _onmouseover="this.style.backgroundColor='#ffff8d'", _onmouseout="this.style.backgroundColor='white'")for k in links])

def callbackcomb2():
    if not request.vars.keyword4: return ''
    query1 = db.quiz.Genre.contains(request.vars.keyword4)
    images = db(query1).select(orderby=db.quiz.Genre)
    links1 = [A(p.Genre + " (Single Correct)", _href=URL('qinfo',args=[p.id])) for p in images]
    query = db.mquiz.Genre.contains(request.vars.keyword4)
    users = db(query).select(orderby=db.mquiz.Genre)
    links = [A(p.Genre +" (Multiple Correct)", _href=URL('mqinfo',args=[p.id])) for p in users]
    links = links+links1
    return DIV(*[DIV(k,  _onmouseover="this.style.backgroundColor='#ffff8d'", _onmouseout="this.style.backgroundColor='white'")for k in links])

@auth.requires_login()
def genre_search():
    var = str(request.vars["var"])
    files = db(db.quiz.Genre==var).select()
    files2 = db(db.mquiz.Genre==var).select()
    return locals()
