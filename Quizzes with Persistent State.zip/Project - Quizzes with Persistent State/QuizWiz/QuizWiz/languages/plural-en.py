#!/usr/bin/env python
# -*- coding: utf-8 -*-
{
# "singular form (0)": ["first plural form (1)", "second plural form (2)", ...],
'account': ['accounts'],
'book': ['books'],
'is': ['are'],
'man': ['men'],
'miss': ['misses'],
'person': ['people'],
'quark': ['quarks'],
'row': ['rows'],
'shop': ['shops'],
'this': ['these'],
'was': ['were'],
'woman': ['women'],
}
