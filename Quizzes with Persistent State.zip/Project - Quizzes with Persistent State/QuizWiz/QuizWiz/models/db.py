# -*- coding: utf-8 -*-

#########################################################################
## This scaffolding model makes your app work on Google App Engine too
## File is released under public domain and you can use without limitations
#########################################################################

## if SSL/HTTPS is properly configured and you want all HTTP requests to
## be redirected to HTTPS, uncomment the line below:
# request.requires_https()

## app configuration made easy. Look inside private/appconfig.ini
from gluon.contrib.appconfig import AppConfig
## once in production, remove reload=True to gain full speed
myconf = AppConfig(reload=True)


if not request.env.web2py_runtime_gae:
    ## if NOT running on Google App Engine use SQLite or other DB
    db = DAL(myconf.take('db.uri'), pool_size=myconf.take('db.pool_size', cast=int), check_reserved=['all'])
else:
    ## connect to Google BigTable (optional 'google:datastore://namespace')
    db = DAL('google:datastore+ndb')
    ## store sessions and tickets there
    session.connect(request, response, db=db)
    ## or store session in Memcache, Redis, etc.
    ## from gluon.contrib.memdb import MEMDB
    ## from google.appengine.api.memcache import Client
    ## session.connect(request, response, db = MEMDB(Client()))

## by default give a view/generic.extension to all actions from localhost
## none otherwise. a pattern can be 'controller/function.extension'
response.generic_patterns = ['*'] if request.is_local else []
## choose a style for forms
response.formstyle = myconf.take('forms.formstyle')  # or 'bootstrap3_stacked' or 'bootstrap2' or other
response.form_label_separator = myconf.take('forms.separator')


## (optional) optimize handling of static files
# response.optimize_css = 'concat,minify,inline'
# response.optimize_js = 'concat,minify,inline'
## (optional) static assets folder versioning
# response.static_version = '0.0.0'
#########################################################################
## Here is sample code if you need for
## - email capabilities
## - authentication (registration, login, logout, ... )
## - authorization (role based authorization)
## - services (xml, csv, json, xmlrpc, jsonrpc, amf, rss)
## - old style crud actions
## (more options discussed in gluon/tools.py)
#########################################################################

from gluon.tools import Auth, Service, PluginManager

auth = Auth(db)
service = Service()
plugins = PluginManager()

## create all tables needed by auth if not custom tables
auth.define_tables(username=False, signature=False)

## configure email
mail = auth.settings.mailer
mail.settings.server = 'logging' if request.is_local else myconf.take('smtp.server')
mail.settings.sender = myconf.take('smtp.sender')
mail.settings.login = myconf.take('smtp.login')

## configure auth policy
auth.settings.registration_requires_verification = False
auth.settings.registration_requires_approval = False
auth.settings.reset_password_requires_verification = True

db.define_table('quiz',
   Field('TITLE',required=True , unique = True,requires=IS_NOT_EMPTY()),
   Field('Genre',required=True),
   Field('image','upload',label="Image"),
   Field('user_id', 'reference auth_user',default=auth.user_id,writable=False,readable=False),
   Field('Difficulty',label='Difficulty level of the quiz',required=True),
   Field('Author','string',default=session.auth.user.first_name if session.auth else None, writable=False,required=True,requires=IS_NOT_EMPTY()),
   Field('date_of_upload','datetime',default=request.now, writable= False),
   Field('votes','integer',writable=False,default=0)
   )
db.quiz.Difficulty.requires=IS_IN_SET(['Easy','Medium','Hard'])

db.define_table('mquiz',
   Field('TITLE',required=True , unique = True,requires=IS_NOT_EMPTY()),
   Field('Genre',required=True),
   Field('image','upload',label="Image"),
   Field('user_id', 'reference auth_user',default=auth.user_id,writable=False,readable=False),
   Field('Difficulty',label='Difficulty level of the quiz',required=True),
   Field('Author','string',default=session.auth.user.first_name if session.auth else None, writable=False,required=True,requires=IS_NOT_EMPTY()),
   Field('date_of_upload','datetime',default=request.now, writable= False),
   Field('votes','integer',writable=False,default=0)
   )
db.mquiz.Difficulty.requires=IS_IN_SET(['Easy','Medium','Hard'])

db.define_table('question',
   Field('quiz_id', 'reference quiz',writable=False,readable=False),
   Field('question','text',required=True,requires=IS_NOT_EMPTY()),
   Field('option1',required=True,requires=IS_NOT_EMPTY()),
   Field('option2',required=True,requires=IS_NOT_EMPTY()),
   Field('option3',required=True,requires=IS_NOT_EMPTY()),
   Field('option4',required=True,requires=IS_NOT_EMPTY()),
   Field('correct_ans',required=True,requires=IS_NOT_EMPTY()),
  )
db.question.quiz_id.requires = IS_IN_DB(db, db.quiz.id, '%(TITLE)s')

db.define_table('multiquestion',
   Field('mquiz_id', 'reference mquiz',writable=False,readable=False),
   Field('question','text',required=True,requires=IS_NOT_EMPTY()),
   Field('option1',required=True,requires=IS_NOT_EMPTY()),
   Field('option2',required=True,requires=IS_NOT_EMPTY()),
   Field('option3',required=True,requires=IS_NOT_EMPTY()),
   Field('option4',required=True,requires=IS_NOT_EMPTY()),
   Field('correct_op1','boolean',default=False),
   Field('correct_op2','boolean',default=False),
   Field('correct_op3','boolean',default=False),
   Field('correct_op4','boolean',default=False),
  )
db.multiquestion.mquiz_id.requires = IS_IN_DB(db, db.mquiz.id, '%(TITLE)s')

db.define_table('myscore',
   Field('quiz_id',writable=False,readable=False),
   Field('question_id',writable=False,readable=False),
   Field('userid',requires=IS_NOT_EMPTY()),
   #Field('num_answered',default=0,writable=False,readable=False),
   Field('ans'),
   Field('correct',default=0),
 #  Field('correct_answered',default=0,writable=False,readable=False),
   )
db.myscore.quiz_id.requires = IS_IN_DB(db, db.quiz.id, '%(TITLE)s')

db.define_table('post',
   Field('quiz_id', 'reference quiz',writable=False,readable=False),
   Field('author','string',default=session.auth.user.first_name if session.auth else None, writable=False,required=True,requires=IS_NOT_EMPTY()),
   Field('body', 'text',required=True))
db.post.quiz_id.requires = IS_IN_DB(db, db.quiz.id, '%(TITLE)s')

db.define_table('mpost',
   Field('quiz_id', 'reference mquiz',writable=False,readable=False),
   Field('author','string',default=session.auth.user.first_name if session.auth else None, writable=False,required=True,requires=IS_NOT_EMPTY()),
   Field('body', 'text',required=True))
db.post.quiz_id.requires = IS_IN_DB(db, db.mquiz.id, '%(TITLE)s')

db.define_table('mscore',
   Field('quiz_id',writable=False,readable=False),
   Field('ques_id'),
   Field('userid',requires=IS_NOT_EMPTY()),
   Field('correct',default=0),
   )
db.myscore.quiz_id.requires = IS_IN_DB(db, db.mquiz.id, '%(TITLE)s')

db.define_table('leaderboard',
                Field('user_id'),
                Field('username'),
                Field('tally','integer'),
               )
